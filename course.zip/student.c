/**
 * @file student.c
 * @author Mohammed Faqraj Ur Rehman (moham50@mcmaster.ca)
 * @date 2022-04-11
 * @brief To return aveerage grade and print student details
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/** 
 * To add the parameter grade into the list of grades.
 * 
 * @param student  To put the grades in the student's list of grades
 * @param grade The grade to be put in the student's list of grades
 * @return nothing
 */ 
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); //To allocate space to the Student grades lists, which initially sets all the values to 0.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);//reallocates more space if required after initial allocation.
  }
  student->grades[student->num_grades - 1] = grade;
}

/** 
 * To return the average grade of the student given in the parameter.
 * 
 * @param student  To put the grades in the student's list of grades
 * @return average grade 
 */ 
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/** 
 * Prints the details of the student including name, Id, grades, average grade.
 * 
 * @param student  To print the student's details
 * @return nothing
 */ 
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * To randomly generate a student from a set of given names and random grade values.
 * 
 * @param grades the number of grades
 * @return new student and it's details
 */ 
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));//To allocate space to the Student grades lists, which initially sets all the values to 0.

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}