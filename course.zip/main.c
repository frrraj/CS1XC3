/**
 * @file main.c
 * @author Mohammed Faqraj Ur Rehman (moham50@mcmaster.ca)
 * @date 2022-04-11
 * @brief 
 *
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a course and assigns a name and code to the course, and enrolls less than  
 * 20 students to the course, and prints the top student, the total number of students passing,
 * and the list of the names of the students passing the course.
 */

int main()
{
  srand((unsigned) time(NULL));
//To allocate space to the course MATH101, which initially sets all the values to 0.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

// Enrolling students in the course, where the students should be than 20.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);


  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  // To print a list of details of all the students that have passed the course. 
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}