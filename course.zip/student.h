/**
 * @file books.h
 * @author Mohammed Faqraj Ur Rehman (moham50@mcmaster.ca)
 * @date 2022-04-11
 * @brief 
 *
 */

/**
* Student type stores a Student's details with fields first name, last name, id, grades.
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name*/
  char last_name[50]; /**< the student's last name*/
  char id[11]; /**< the student's id*/
  double *grades; /**< the student's list of grades*/
  int num_grades; /**< the student's number of grades*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
