/**
 * @file course.h
 * @author Mohammed Faqraj Ur Rehman (moham50@mcmaster.ca)
 * @date 2022-04-11 
 * @brief 
 *
 */
 
#include "student.h"
#include <stdbool.h>

/**
* Course type stores a Course with fields name, code, total students.
*
*/
 
typedef struct _course 
{
  char name[100]; /**< the course's name */
  char code[10]; /**< the course's code */
  Student *students;
  int total_students; /**< the total students in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


