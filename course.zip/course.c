/**
 * @file course.c
 * @author Mohammed Faqraj Ur Rehman (moham50@mcmaster.ca)
 * @date 2022-04-11
 * @brief Details related to total students in a course and their details
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>


/** 
 * Prints and displays the total students added to the course.
 * 
 * @param course  To add course details and the students enrolled in it.
 * @param student Adding students to the course
 * @return nothing
 */ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //To allocate space to the Student, which initially sets all the values to 0.
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //reallocates more space if required after initial allocation. 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Prints the details of the course including name, code, total students.
 * 
 * @param course To add course details and the students enrolled in it.
 * @return nothing
 */ 
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * To return the top student in the course.
 *
 * @param course  to show the top student in the course
 * @return the top student
 */ 
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * To return a list of the details of the total students passing the course.
 *
 * @param course  To show the course 
 * @param total_passing To find total students passing the course
 * @return list of passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //To allocate space to the Student, which initially sets all the values to 0.

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}